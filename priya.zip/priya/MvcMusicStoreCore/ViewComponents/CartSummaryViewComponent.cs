﻿using Microsoft.AspNetCore.Mvc;
using MvcMusicStoreCore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcMusicStoreCore.ViewComponents
{
    public class CartSummaryViewComponent : ViewComponent
    {
        private readonly ShoppingCart shoppingCart;

        public CartSummaryViewComponent(ShoppingCart shoppingCart)
        {
            this.shoppingCart = shoppingCart;
        }

        public IViewComponentResult Invoke()
        {
            ViewData["CartCount"] = shoppingCart.GetCount();

            return View();
        }
    }
}
