﻿using Microsoft.AspNetCore.Mvc;
using MvcMusicStoreCore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcMusicStoreCore.ViewComponents
{
    public class GenreMenuViewComponent : ViewComponent
    {
        private readonly MusicStoreEntities storeDB;

        public GenreMenuViewComponent(MusicStoreEntities musicStoreEntities)
        {
            this.storeDB = musicStoreEntities;
        }

        public IViewComponentResult Invoke()
        {
            var genres = storeDB.Genres.ToList();

            return View(genres);
        }
    }
}
